
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Navbar } from 'react-bootstrap';
import NavbarComp from './Components/NavbarComp';

function App() {
  return (
    <div className="App">
    <NavbarComp/>
    </div>
  );
}

export default App;
