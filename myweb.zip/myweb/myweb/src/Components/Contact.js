import React, { useState } from "react";
import {useForm} from "react-hook-form";


function Contact() {
    const [state, setState] = useState({
        name: "",   
        email: "",
        studentid: "",
        message: "",
      });
      const { name, email, studentid,subject, message } = state;
   
      const{ handleSubmit}=useForm();

      const onSubmit =(data) =>{
        console.log(data)
      };
   

  const handleInputChange = (e) => {
    let { name, value } = e.target;
    setState({ ...state, [name]: value });
  };

  return(
   <section className="contact-section">
    <div className="container">
    <div className="row justify-content-center">
    <div className="col-md-10">
    <div className="wrapper">
    <div className="row no-gutters">
      <div className="col-md-6">
      <div className="contact-wrap w-100 p-lg-5 p-4">
      <h3 className="mb-4">Send us a message, We can assist you</h3>
        <form onSubmit={handleSubmit(onSubmit)} >
      
        <div className="row">
        <div className="form-group">
        <input
           type="text"
           className="form-control"
           name="name"
           placeholder="Name"
            onChange={handleInputChange}
            value={name}
            
           
             />
         </div>
         </div>
         <div className="col-md-12">
       <div className="form-group">
        <input
         type="Text"
        className="form-control"
        name="studentid"
        placeholder="Student ID"
        onChange={handleInputChange}
        value={studentid}
 
                         
     />
      </div>
      </div>
         <div className="col-md-12">
         <div className="form-group">
         <input
          type="email"
          className="form-control"
          name="email"
         placeholder="Email"
         onChange={handleInputChange}
         value={email}
      
         />
      </div>
      </div>


      <div className="col-md-12">
     <div className="form-group">
     <input
      type="text"
     className="form-control"
     name="subject"
     placeholder="Subject"
     onChange={handleInputChange}
     value={subject}     
           
     />
      </div>
      </div>
      <div className="col-md-12">
     <div className="form-group">
     <textarea
       type="text"
       className="form-control"
       name="message"
       placeholder="Message"
       cols="30"
       rows="6"
       onChange={handleInputChange}
       value={message}
      
          ></textarea>
       </div>
      </div>
     <div className="col-md-12">
      <div className="form-group">
      <input
      type="submit"
      value="Send Message"
      className="btn btn-primary"
     />
    </div>
    </div>
    
    </form>
   </div>
    </div>
   
    </div>
    </div>
    </div>
   </div>
    </div> 
   </section>

  );

}

    export default Contact;
