import React, { Component } from 'react';
import Background from './image/BVC.jpg';


export default class Home extends Component {
    render() {
        const mystyle = {
        color: "white",
        backgroundColor: "DodgerBlue",
        padding: "60px",
        fontFamily: "Brush Script MT"
        
      };
        return (
            <div >
                <img src={Background} height='10000%' width='100%'/>
               
                <h1 style={mystyle}> Welcome to Bow Valley Course Registration </h1>
            </div>
        )
    }
}
