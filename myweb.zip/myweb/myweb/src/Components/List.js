import React from 'react'
import {CurrentCourses} from './Registration';


function ListCourses(){

    return(
        <table>
            <thead>
                <tr>
                    <th>Course Id</th>
                    <th>Course Name</th>
                    <th>Class Time</th>
                </tr>
            </thead>
            <tbody>
                <>
                    {CurrentCourses.map(course =>{
                        return(<tr>
                            <td>{course.CourseId}</td>
                            <td>{course.Name}</td>
                            <td>{course.Time}</td>
                        </tr>)
                    })}
                </>
            </tbody>
        </table>
    )
}

export default ListCourses;