import React, { Component } from 'react'
import { Navbar,Nav,NavDropdown,Container} from 'react-bootstrap'
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

import Contact from './Contact';
import Home from './Home';
import Signup from './Signup';
import Login from './Login';
import StaffLogin from './StaffLogin';
import Registration from './Registration'
import ListCourses from './List'

export default class NavbarComp extends Component {
    render() {
        return (
          <Router>
            <div>
  <Navbar bg="dark" variant={"dark"} expand="lg" >
  <Container>
    <Navbar.Brand href="#home">Bow Valley College</Navbar.Brand>
    <Navbar.Toggle aria-controls="basic-navbar-nav" />
    <Navbar.Collapse id="basic-navbar-nav">
      <Nav className="me-auto">
        <Nav.Link as={Link} to ={"/home"}>Home</Nav.Link>
        <Nav.Link as={Link} to = {"/Login"}>login</Nav.Link>
        <Nav.Link as={Link} to ={"/Contact"}>Contact Us</Nav.Link>
        <Nav.Link as={Link} to ={"/Signup"}>Sign Up</Nav.Link>
        <NavDropdown title="Course Registration" id="basic-nav-dropdown">
        <NavDropdown.Item href="#action/3.1"><Nav.Link as={Link} to ={"/List"}>List of Courses</Nav.Link></NavDropdown.Item>
          <NavDropdown.Item href="#action/3.2"><Nav.Link as={Link} to ={"/Registration"}>Add your courses</Nav.Link></NavDropdown.Item>
           <NavDropdown.Divider />
         
        </NavDropdown>
       
      </Nav>
    </Navbar.Collapse>
  </Container>
</Navbar>
   </div>

      <div>
      <Switch>
          
          <Route path="/Home">
            <Home />

          </Route>
          <Route path="/Login">
            <Login/>
            </Route>
            <Route path="/StaffLogin">
              <StaffLogin/>
            </Route>
          <Route path="/contact">
            <Contact/>
             </Route>
             <Route path="/signup">
            <Signup />
             </Route>
             <Route path="/Registration">
            <Registration />
             </Route>

             <Route path="/List">
            <ListCourses />
             </Route>
        </Switch>
      </div>
   </Router>
        );
    }
}
