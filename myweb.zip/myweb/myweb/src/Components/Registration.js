import React from "react";

 const Courses =
    [{id: 1, CourseId: "Pr111",Name: "Project Management", Time: "9:30am - 11:00am mon & wed"},
    {id: 2,CourseId: "Pr111",Name: "Project Management", Time: "8:00am - 9:30am mon & wed"},
    {id: 3,CourseId: "Pr111",Name: "Project Management", Time: "11:00am - 12:30pm tues & thurs"}
    
    ];

    
const CurrentCourses = [];




function Registration(){

    

      let currentCourse = {
      id: 0,
      CourseId: "",
      Name: "",
      Time: ""
  };
   
    

    const handleChange = (e) => {
        let temp = JSON.parse(e.target.value);
       currentCourse = {
         id : temp.id,
         CourseId: temp.CourseId,
         Name: temp.Name,
         Time: temp.Time
    };
        console.log(currentCourse);
        console.log(CurrentCourses);
    }

    const handleSubmit = (e) =>{
       e.preventDefault();
        CurrentCourses.push(currentCourse);
        console.log(CurrentCourses);

    }
    

    return(
        
        <form onSubmit = {handleSubmit}>
        <fieldset>
            <legend>Course Registration</legend>
            <select onChange = {handleChange}
                value = {currentCourse}>
                {Courses.map(course => {
                    return <option key ={course.id} value = {JSON.stringify(course)}>{course.Name + course.Time}</option>
                })}
                </select><br/>
                <button type = "submit"> register</button>
  
        </fieldset>
        

        </form>
        
    )
}

export {CurrentCourses};
export default Registration;